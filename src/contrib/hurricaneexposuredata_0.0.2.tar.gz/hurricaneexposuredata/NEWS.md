# hurricaneexposuredata 0.0.2

* Finalized lists of authors, contributors, and funding support. 
* Finalized documentation for current data. 
* Added a `NEWS.md` file to track changes to the package.



